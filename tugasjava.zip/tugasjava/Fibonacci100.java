public class Fibonacci100 {
    public static void main(String[] args) {
        int a = 0, b = 1;

        System.out.println("Deret Fibonacci dari 0 sampai 100:");

        while (a <= 100) {
            System.out.print(a + " ");
            int c = a + b;
            a = b;
            b = c;
        }
    }
}

