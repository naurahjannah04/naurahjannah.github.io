public class JadwalShift {
    public static void main(String[] args) {
        String[] karyawan = {"Andi", "Budi", "Citra", "Dina", "Eka"};
        int hari = 1;

        System.out.println("=== Jadwal Shift Harian (Setiap Pasangan Unik Sekali) ===\n");

        for (int i = 0; i < karyawan.length; i++) {
            for (int j = i + 1; j < karyawan.length; j++) {
                System.out.println("Hari ke-" + hari + ": " + karyawan[i] + " & " + karyawan[j]);
                hari++;
            }
        }

        System.out.println("\nTotal hari dalam satu siklus: " + (hari - 1));
    }
}


