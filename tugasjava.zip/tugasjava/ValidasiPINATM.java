import java.util.Scanner;

public class ValidasiPINATM {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        final String PIN_BENAR = "123456";
        int percobaan = 0;

        while (percobaan < 3) {
            System.out.print("Masukkan PIN Anda (6 digit): ");
            String pin = input.nextLine();

            if (!pin.matches("\\d{6}")) {
                System.out.println("Format PIN tidak valid! Harus 6 digit angka.\n");
                continue; 
            }

            if (pin.equals(PIN_BENAR)) {
                System.out.println("Selamat datang! Transaksi dapat dilanjutkan.");
                break;
            } else {
                percobaan++;
                if (percobaan < 3) {
                    System.out.println("PIN salah. Sisa percobaan: " + (3 - percobaan) + "\n");
                } else {
                    System.out.println("Kartu diblokir. Silakan hubungi bank.");
                }
            }
        }

        input.close();
    }
}
