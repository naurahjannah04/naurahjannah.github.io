 import java.util.Scanner;

public class FibonacciBatasB {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan batas bawah: ");
        int min = input.nextInt();

        System.out.print("Masukkan batas atas: ");
        int max = input.nextInt();

        int a = 0, b = 1;

        System.out.println("Deret Fibonacci dari " + min + " sampai " + max + ":");

        while (a <= max) {
            if (a >= min) {
                System.out.print(a + " ");
            }
            int c = a + b;
            a = b;
            b = c;
        }

        input.close();
    }
}


