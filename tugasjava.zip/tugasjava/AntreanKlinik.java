import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class AntreanKlinik {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Queue<Integer> antrean = new LinkedList<>();

        final int MAKS_ANTRIAN = 10;

        System.out.print("Masukkan jumlah pasien yang datang: ");
        int totalPasien = input.nextInt();

        for (int i = 1; i <= totalPasien; i++) {
            if (antrean.size() >= MAKS_ANTRIAN) {
                // Layani satu pasien (hapus dari antrean)
                int dilayani = antrean.poll();
                System.out.println("Antrean penuh. Pasien #" + dilayani + " selesai dilayani.");
            }

            // Tambahkan pasien baru ke antrean
            antrean.offer(i);
            System.out.println("Pasien #" + i + " masuk ke antrean. Total antrean: " + antrean.size());
        }

        // Setelah semua pasien ditangani, tampilkan isi antrean
        System.out.println("\nPasien yang masih dalam antrean:");
        for (int nomor : antrean) {
            System.out.println("Pasien #" + nomor);
        }

        input.close();
    }
}
